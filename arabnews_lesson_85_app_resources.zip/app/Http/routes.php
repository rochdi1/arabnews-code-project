<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

//////// SingleTon Start
$singletonarray = [
					'at'=>'admin',
					'theme'=>'themes.master',
					'aurl'=>'admin',
					'language'=>['ar','en'],
					];
foreach($singletonarray as $key => $value)
{		
	app()->singleton($key,function() use ($value){
		return $value;
	});
}

//////// SingleTon End
/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::group(['middleware' => ['web']], function () {


	Route::post('multiupload','NewsController@MultiUpload');





    
	Route::group(['prefix'=>app('aurl')],function(){

		Route::get('login','AdminController\HomeController@login');
		Route::post('login','AdminController\HomeController@post_login');

		Route::group(['middleware'=>'auth_admin'],function(){

		Route::get('logout','AdminController\HomeController@logout');
		Route::get('/','AdminController\HomeController@Index');
		Route::get('settings','AdminController\Settings@index');
		Route::post('settings','AdminController\Settings@save');
		Route::get('artisan','AdminController\Settings@ArtissanCommand');
		Route::post('artisan','AdminController\Settings@ArtisanPost');
		Route::resource('department_news','DepNews');
		Route::resource('news','NewsController');
		Route::resource('department_product','DepProduct');
		Route::post('department_product/check/parent','DepProduct@check_parent');


	 });


	});


});
