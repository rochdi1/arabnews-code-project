<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DepartmentProducts extends Model
{
    protected $table = 'department_products';
}
