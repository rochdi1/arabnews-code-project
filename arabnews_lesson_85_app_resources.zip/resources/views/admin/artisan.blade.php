@extends(app('at').'.index')
@section('admin')


<!-- Widget ID (each widget will need unique ID)-->
			<div class="jarviswidget" id="wid-id-7" data-widget-editbutton="false" data-widget-custombutton="false">
				<!-- widget options:
					usage: <div class="jarviswidget" id="wid-id-0" data-widget-editbutton="false">
					
					data-widget-colorbutton="false"	
					data-widget-editbutton="false"
					data-widget-togglebutton="false"
					data-widget-deletebutton="false"
					data-widget-fullscreenbutton="false"
					data-widget-custombutton="false"
					data-widget-collapsed="true" 
					data-widget-sortable="false"
					
				-->
				<header>
					<span class="widget-icon"> <i class="fa fa-edit"></i> </span>
					<h2>{{$title}} </h2>				
					
				</header>

				<!-- widget div-->
				<div>
					
					<!-- widget edit box -->
					<div class="jarviswidget-editbox">
						<!-- This area used as dropdown edit box -->
						
					</div>
					<!-- end widget edit box -->
					
					<!-- widget content -->
					<div class="widget-body no-padding">
						
						{!! Form::open(['url'=>url()->current(),'id'=>'review-form','class'=>'smart-form']) !!}
							<header>
								{{$title}} 
							</header>
							<fieldset>


								<section>
									<label class="input">Artisan List</label>
									<select name="command" class="form-control" >
									 <option value="make:model">make:model</option>		
									 <option value="make:seeder">make:seeder</option>		
									 <option value="make:migration">make:migration</option>		
									 <option value="make:controller">make:controller</option>		
									</select>
								</section>

								<section>
									<label class="input"> Command  
										<input type="text" name="name"  id="name" placeholder="Your Command Here">
									</label>
								</section>
								<input type="submit" name="go" value="Go"></input>

 
						{!! Form::close() !!}						
						
					</div>
					<!-- end widget content -->
					
				</div>
				<!-- end widget div -->
				
			</div>
			<!-- end widget -->	

@stop