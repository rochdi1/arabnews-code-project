 
<div class="col-xs-12 col-sm-7 col-md-7 col-lg-7">
<?php /*
	<h1 class="page-title txt-color-blueDark"><a href="{{url('/'.app('aurl'))}}"><i class="fa-fw fa fa-home"></i> {{trans('main.home')}} </a>

	<?php 
	 $path_segment = 10;
	 $sublink = '';
	 ?>
	@for($i=2;$i < $path_segment; $i++)
	@if(!empty(Request::segment($i)) and !is_numeric(Request::segment($i)))

	@if($i != 2)
	<?php $sublink .= '/'; ?>
	@endif

	<?php $sublink .= Request::segment($i); ?>
	<span>> <a href="{{url(app('aurl').'/'.$sublink)}}">{{trans('main.'.Request::segment($i))}}</a></span>
	@endif
	@endfor

	</h1>
*/?>
</div>
