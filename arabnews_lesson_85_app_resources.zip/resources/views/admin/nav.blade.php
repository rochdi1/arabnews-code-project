<!-- Left panel : Navigation area -->
		<!-- Note: This width of the aside area can be adjusted through LESS variables -->
		<aside id="left-panel">

			<!-- User info -->
			<div class="login-info">
				<span> <!-- User image size is adjusted inside CSS, it should stay as it --> 
					
					<a href="javascript:void(0);" id="show-shortcut" data-action="toggleShortcut">
						<img src="img/avatars/sunny.png" alt="me" class="online" /> 
						<span>
							{{auth()->user()->name}}
						</span>
						<i class="fa fa-angle-down"></i>
					</a> 
					
				</span>
			</div>
			<!-- end user info -->

			<!-- NAVIGATION : This navigation is also responsive-->
			<nav>
				<ul>
					<li class="">
						<a href="{{url('/')}}" title="Dashboard"><i class="fa fa-lg fa-fw fa-home"></i> 
						<span class="menu-item-parent">{{trans('main.dashboard')}}</span></a>
					</li>

					<li class="">
						<a href="{{url(app('aurl').'/settings')}}" title=""><i class="fa fa-lg fa-fw fa-cog"></i> 
						<span class="menu-item-parent">{{trans('main.settings')}}</span></a>
					</li>
					
					<li class="@if(preg_match('/news|department_news/i',Request::segment(2))) open @endif">
						<a href="#" title=""><i class="fa fa-lg fa-fw fa-file"></i> 
						<span class="menu-item-parent">{{trans('main.news')}}</span></a>
						<ul @if(preg_match('/news|department_news/i',Request::segment(2))) style="display: block;" @endif>
							<li><a href="{{url(app('aurl').'/department_news')}}">{{trans('main.department_news')}}</a></li>
							<li><a href="{{url(app('aurl').'/news')}}">{{trans('main.news')}}</a></li>
						</ul>
					</li>
					<li class="@if(preg_match('/products|department_product/i',Request::segment(2))) open @endif">
						<a href="#" title=""><i class="fa fa-lg fa-fw fa-file"></i> 
						<span class="menu-item-parent">{{trans('main.products')}}</span></a>
						<ul @if(preg_match('/products|department_product/i',Request::segment(2))) style="display: block;" @endif>
							<li><a href="{{url(app('aurl').'/department_product')}}">{{trans('main.department_product')}}</a></li>
							<li><a href="{{url(app('aurl').'/products')}}">{{trans('main.products')}}</a></li>
						</ul>
					</li>

					
				</ul>
			</nav>
			<span class="minifyme" data-action="minifyMenu"> 
				<i class="fa fa-arrow-circle-left hit"></i> 
			</span>

		</aside>
		<!-- END NAVIGATION -->


			<!-- MAIN PANEL -->
		<div id="main" role="main">

			<!-- RIBBON -->
			<div id="ribbon">

				<span class="ribbon-button-alignment"> 
					<span id="refresh" class="btn btn-ribbon" data-action="resetWidgets" data-title="refresh"  rel="tooltip" data-placement="bottom" data-original-title="<i class='text-warning fa fa-warning'></i> Warning! This will reset all your widget settings." data-html="true">
						<i class="fa fa-refresh"></i>
					</span> 
				</span>

				<!-- breadcrumb -->
				<ol class="breadcrumb">
				<li><a href="{{url('/'.app('aurl'))}}"><i class="fa-fw fa fa-home"></i> {{trans('main.home')}} </a></li>
					<?php 
					 $path_segment = 10;
					 $sublink = '';
					 ?>
					@for($i=2;$i < $path_segment; $i++)
					@if(!empty(Request::segment($i)) and !is_numeric(Request::segment($i)))

					@if($i != 2)
					<?php $sublink .= '/'; ?>
					@endif

					<?php $sublink .= Request::segment($i); ?>
					<li> <a href="{{url(app('aurl').'/'.$sublink)}}">{{trans('main.'.Request::segment($i))}}</a></li>
					@endif
					@endfor	
					@if(!empty($master))
					 / {!! $master !!}
					@endif			 
				</ol>
				<!-- end breadcrumb -->

				<!-- You can also add more buttons to the
				ribbon for further usability

				Example below:

				<span class="ribbon-button-alignment pull-right">
				<span id="search" class="btn btn-ribbon hidden-xs" data-title="search"><i class="fa-grid"></i> Change Grid</span>
				<span id="add" class="btn btn-ribbon hidden-xs" data-title="add"><i class="fa-plus"></i> Add</span>
				<span id="search" class="btn btn-ribbon" data-title="search"><i class="fa-search"></i> <span class="hidden-mobile">Search</span></span>
				</span> -->

			</div>
			<!-- END RIBBON -->

			<!-- MAIN CONTENT -->
			<div id="content">

			<div class="row hidden">
					@include(app('at').'.breadcrumbs')
					<div class="col-xs-12 col-sm-5 col-md-5 col-lg-8 ">
						<ul id="sparks" class="">
							<li class="sparks-info">
								<h5> My Income <span class="txt-color-blue">$47,171</span></h5>
								<div class="sparkline txt-color-blue hidden-mobile hidden-md hidden-sm">
									1300, 1877, 2500, 2577, 2000, 2100, 3000, 2700, 3631, 2471, 2700, 3631, 2471
								</div>
							</li>
							<li class="sparks-info">
								<h5> Site Traffic <span class="txt-color-purple"><i class="fa fa-arrow-circle-up"></i>&nbsp;45%</span></h5>
								<div class="sparkline txt-color-purple hidden-mobile hidden-md hidden-sm">
									110,150,300,130,400,240,220,310,220,300, 270, 210
								</div>
							</li>
							<li class="sparks-info">
								<h5> Site Orders <span class="txt-color-greenDark"><i class="fa fa-shopping-cart"></i>&nbsp;2447</span></h5>
								<div class="sparkline txt-color-greenDark hidden-mobile hidden-md hidden-sm">
									110,150,300,130,400,240,220,310,220,300, 270, 210
								</div>
							</li>
						</ul>
					</div>
				</div>

