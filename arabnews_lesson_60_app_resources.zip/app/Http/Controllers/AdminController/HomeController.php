<?php

namespace App\Http\Controllers\AdminController;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Http\Requests;

class HomeController extends Controller
{

   public function Index()
   {
   	return view(app('at').'.home');
   }
}
