<?php 

return [
	'signin'=>'Sign In',
	'email'=>'E-mail',
	'password'=>'Password',
	'worng1'=>'Please enter email address',
	'worng2'=>' Enter your password',
	'rememberme'=>' Stay signed in',
	'login'=>' Login',
	'account_loggedin'=>'Your Account is Logged You Are Welcome',
	'account_have_error_login'=>'Please Check Your Email And password And try again',
	];